import csv
import ctypes
import os
import platform
import random
import statistics
import sys
import time
import tracemalloc
from ipaddress import IPv4Address

ARQUIVO = "base_ip2location_10000_faixas_ipv4.csv"


class NoArvore:
    def __init__(self, inicio, fim, pais):
        self.inicio = inicio
        self.fim = fim
        self.pais = pais
        self.esquerda = None
        self.direita = None


def obter_info_hardware():
    py_ver = sys.version.split()[0]
    sistema = f"{platform.system()} {platform.release()}"
    cpu = platform.processor() or f"{os.cpu_count()} núcleos"
    ram_gb = "N/D"

    try:
        if sys.platform == "win32":
            class MEMORYSTATUSEX(ctypes.Structure):
                _fields_ = [
                    ("dwLength", ctypes.c_ulong),
                    ("dwMemoryLoad", ctypes.c_ulong),
                    ("ullTotalPhys", ctypes.c_ulonglong),
                    ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong),
                    ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong),
                    ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("sullAvailExtendedVirtual", ctypes.c_ulonglong),
                ]

            stat = MEMORYSTATUSEX(dwLength=ctypes.sizeof(MEMORYSTATUSEX))
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat)):
                ram_gb = f"{stat.ullTotalPhys / (1024 ** 3):.2f} GB"
        elif os.path.exists("/proc/meminfo"):
            with open("/proc/meminfo", encoding="utf-8") as f:
                for linha in f:
                    if linha.startswith("MemTotal:"):
                        kb = int(linha.split()[1])
                        ram_gb = f"{kb / (1024 ** 2):.2f} GB"
                        break
    except Exception:
        pass

    return py_ver, sistema, cpu, ram_gb


def construir_arvore_balanceada(faixas_ordenadas):
    if not faixas_ordenadas:
        return None
    meio = len(faixas_ordenadas) // 2
    inicio, fim, pais = faixas_ordenadas[meio]
    no = NoArvore(inicio, fim, pais)
    no.esquerda = construir_arvore_balanceada(faixas_ordenadas[:meio])
    no.direita = construir_arvore_balanceada(faixas_ordenadas[meio + 1:])
    return no


def calcular_altura(no):
    if no is None:
        return 0
    return 1 + max(calcular_altura(no.esquerda), calcular_altura(no.direita))


def carregar_arvore(caminho):
    faixas = []
    with open(caminho, encoding="utf-8-sig", newline="") as arquivo:
        leitor = csv.DictReader(arquivo)
        for linha in leitor:
            inicio = int(linha["IP inicial (inteiro)"])
            fim = int(linha["IP final (inteiro)"])
            pais = linha["País"]
            faixas.append((inicio, fim, pais))

    faixas.sort(key=lambda faixa: faixa[0])

    for i in range(1, len(faixas)):
        if faixas[i - 1][1] >= faixas[i][0]:
            raise ValueError("Existem faixas IPv4 sobrepostas.")

    tracemalloc.start()
    raiz = construir_arvore_balanceada(faixas)
    memoria_atual, _ = tracemalloc.get_traced_memory()
    tracemalloc.stop()

    return raiz, faixas, memoria_atual


def buscar_pais_inteiro(raiz, alvo):
    atual = raiz
    nos_visitados = 0

    while atual is not None:
        nos_visitados += 1
        if alvo < atual.inicio:
            atual = atual.esquerda
        elif alvo > atual.fim:
            atual = atual.direita
        else:
            return atual.pais, nos_visitados

    return None, nos_visitados


def buscar_pais(raiz, endereco_ip):
    alvo = int(IPv4Address(endereco_ip))
    return buscar_pais_inteiro(raiz, alvo)


def gerar_consultas_fora_da_base(faixas, quantidade):
    fora = []

    # 1. Endereços abaixo da primeira faixa (borda esquerda da árvore)
    limite_inferior = faixas[0][0]
    qtd_abaixo = min(quantidade // 3, limite_inferior)
    for i in range(1, qtd_abaixo + 1):
        fora.append((limite_inferior - i, None))

    # 2. Endereços em lacunas internas entre faixas consecutivas (quando existirem)
    lacunas = []
    for i in range(len(faixas) - 1):
        fim_atual = faixas[i][1]
        inicio_prox = faixas[i + 1][0]
        if fim_atual + 1 < inicio_prox:
            lacunas.append((fim_atual + 1, inicio_prox - 1))

    qtd_lacunas = 0
    if lacunas:
        alvo_lacunas = quantidade // 3
        for _ in range(alvo_lacunas):
            ini_lac, fim_lac = random.choice(lacunas)
            fora.append((random.randint(ini_lac, fim_lac), None))
        qtd_lacunas = alvo_lacunas

    # 3. Endereços acima da última faixa (borda direita da árvore)
    qtd_acima = quantidade - len(fora)
    limite_superior = faixas[-1][1] + 1
    for i in range(qtd_acima):
        fora.append((limite_superior + i, None))

    distribuicao = {
        "abaixo": qtd_abaixo,
        "lacunas": qtd_lacunas,
        "acima": qtd_acima,
        "lacunas_na_base": len(lacunas),
    }
    return fora, distribuicao


def executar_benchmark(raiz, faixas, total_consultas=1_000_000, execucoes=3):
    random.seed(42)
    metade = total_consultas // 2
    consultas = []

    # 500.000 IPs pertencentes às faixas carregadas
    for _ in range(metade):
        inicio, fim, pais_esperado = random.choice(faixas)
        ip_valido = random.randint(inicio, fim)
        consultas.append((ip_valido, pais_esperado))

    # 500.000 IPs fora da base
    fora, distribuicao = gerar_consultas_fora_da_base(faixas, metade)
    consultas.extend(fora)
    random.shuffle(consultas)

    tempos = []
    max_nos_geral = 0
    erros = 0

    for _ in range(execucoes):
        inicio_tempo = time.perf_counter()
        for ip_int, esperado in consultas:
            obtido, nos_visitados = buscar_pais_inteiro(raiz, ip_int)
            if nos_visitados > max_nos_geral:
                max_nos_geral = nos_visitados
            if obtido != esperado:
                erros += 1
        fim_tempo = time.perf_counter()
        tempos.append(fim_tempo - inicio_tempo)

    return tempos, max_nos_geral, erros, distribuicao


py_ver, sistema, cpu, ram_gb = obter_info_hardware()
raiz, faixas, memoria_nos = carregar_arvore(ARQUIVO)
altura = calcular_altura(raiz)

print(f"Ambiente: Python {py_ver} | {sistema} | CPU: {cpu} | RAM: {ram_gb}")
print(f"Faixas carregadas na árvore: {len(faixas)}")
print(f"Altura da árvore: {altura} níveis")
print(f"Memória dos nós da árvore: {memoria_nos / (1024 * 1024):.2f} MB")

for ip in ["1.0.16.3", "1.0.0.1"]:
    resultado, nos = buscar_pais(raiz, ip)
    texto = resultado if resultado is not None else "Não encontrado"
    print(f"{ip} -> {texto} (nós visitados: {nos})")

tempos, max_nos, total_erros, dist = executar_benchmark(raiz, faixas)
print(
    f"Consultas fora da base ({dist['lacunas_na_base']} lacunas internas na amostra): "
    f"{dist['abaixo']} abaixo | {dist['lacunas']} em lacunas | {dist['acima']} acima"
)
print(f"Máximo de nós visitados no benchmark: {max_nos}")
print(f"Total de erros em 3.000.000 de buscas: {total_erros}")
for idx, t in enumerate(tempos, start=1):
    print(f"Execução {idx}: {t:.6f} s")
print(f"Mediana: {statistics.median(tempos):.6f} s | Média: {statistics.mean(tempos):.6f} s")
import ipaddress
import time


def converter_ip(ip_texto):
    
    return int(ipaddress.IPv4Address(ip_texto))


def montar_tabela(total_faixas=10000, tamanho=256):
    faixas = []
    inicio_atual = int(ipaddress.IPv4Address("10.0.0.0"))

    for idx in range(total_faixas):
        fim_atual = inicio_atual + tamanho - 1
        faixas.append((inicio_atual, fim_atual, f"faixa_{idx + 1}"))
        inicio_atual = fim_atual + 1

    return faixas


def buscar_ip_linear(faixas, ip_procurado):
    t0 = time.perf_counter()
    alvo = converter_ip(ip_procurado)
    passos = 0

    for inicio, fim, nome in faixas:
        passos += 1
        if inicio <= alvo <= fim:
            duracao_ms = (time.perf_counter() - t0) * 1000
            return nome, passos, duracao_ms

    duracao_ms = (time.perf_counter() - t0) * 1000
    return None, passos, duracao_ms


faixas_10k = montar_tabela()

testes = [
    ("Primeira faixa", "10.0.0.10"),
    ("Meio da tabela", "10.19.136.10"),
    ("Última faixa", "10.39.255.10"),
    ("Fora da tabela", "172.16.0.1"),
]

for rotulo, ip in testes:
    achou, passos, ms = buscar_ip_linear(faixas_10k, ip)
    print(f"{rotulo} ({ip}) -> {achou} | comparacoes: {passos} | {ms:.4f} ms")
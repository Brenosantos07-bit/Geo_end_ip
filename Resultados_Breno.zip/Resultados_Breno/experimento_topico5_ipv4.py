"""EXEMPLO DIDATICO COM AUXILIO DE IA. Nao apresentar como trabalho sem assistencia.

Executar na mesma pasta de base_ip2location_10000_faixas_ipv4.csv:
    py experimento_topico5_ipv4.py

Faz 1.000.000 de consultas na amostra REAL IP2Location LITE DB1:
500.000 dentro das faixas amostradas e 500.000 nos intervalos vazios da amostra.
O cronometro mede somente as buscas, nao geracao, validacao ou leitura do CSV.
"""
from bisect import bisect_right
import csv
import json
import platform
import random
import statistics
from pathlib import Path
from time import perf_counter

BASE = Path(__file__).with_name('base_ip2location_10000_faixas_ipv4.csv')
SEMENTE = 2026
TOTAL = 1_000_000
REPETICOES = 3


def carregar_faixas():
    faixas = []
    with BASE.open('r', encoding='utf-8-sig', newline='') as arq:
        for linha in csv.DictReader(arq):
            faixas.append((int(linha['IP inicial (inteiro)']),
                           int(linha['IP final (inteiro)']), linha['País']))
    faixas.sort()
    assert len(faixas) == 10_000
    assert all(faixas[i][1] < faixas[i + 1][0] for i in range(len(faixas) - 1))
    return faixas


def busca_binaria(faixas, alvo):
    esquerda, direita = 0, len(faixas) - 1
    while esquerda <= direita:
        meio = (esquerda + direita) // 2
        inicio, fim, pais = faixas[meio]
        if alvo < inicio:
            direita = meio - 1
        elif alvo > fim:
            esquerda = meio + 1
        else:
            return pais
    return None


def gerar_consultas(faixas):
    """Um conjunto fixo para ser reutilizado na comparacao entre algoritmos."""
    rng = random.Random(SEMENTE)
    lacunas = [(faixas[i][1] + 1, faixas[i + 1][0] - 1)
               for i in range(len(faixas) - 1)
               if faixas[i][1] + 1 <= faixas[i + 1][0] - 1]
    if not lacunas:
        raise ValueError('Nao ha lacunas para gerar consultas ausentes')
    consultas = []
    for _ in range(TOTAL // 2):
        ini, fim, _pais = faixas[rng.randrange(len(faixas))]
        consultas.append(rng.randint(ini, fim))
    for _ in range(TOTAL // 2):
        ini, fim = lacunas[rng.randrange(len(lacunas))]
        consultas.append(rng.randint(ini, fim))
    rng.shuffle(consultas)
    return consultas


def verificar_respostas(faixas, consultas):
    # Validador independente usando bisect sobre IPs iniciais.
    inicios = [x[0] for x in faixas]
    erros = 0
    encontrados = 0
    for ip in consultas:
        j = bisect_right(inicios, ip) - 1
        esperado = faixas[j][2] if j >= 0 and ip <= faixas[j][1] else None
        obtido = busca_binaria(faixas, ip)
        erros += (obtido != esperado)
        encontrados += (obtido is not None)
    return erros, encontrados


def executar():
    faixas = carregar_faixas()
    consultas = gerar_consultas(faixas)
    erros, encontrados = verificar_respostas(faixas, consultas)
    if erros:
        raise RuntimeError(f'Busca apresentou {erros} respostas incorretas')
    assert encontrados == TOTAL // 2
    # Aquecer a funcao antes das medidas.
    for ip in consultas[:10_000]:
        busca_binaria(faixas, ip)

    tempos = []
    for repeticao in range(REPETICOES):
        achados = 0
        t0 = perf_counter()
        for ip in consultas:
            achados += (busca_binaria(faixas, ip) is not None)
        segundos = perf_counter() - t0
        assert achados == encontrados
        tempos.append(segundos)
        print(f'Execucao {repeticao + 1}: {segundos:.6f} s')

    resultado = {
        'origem': 'amostra de IP2Location LITE DB1 fornecida pelo usuario',
        'linguagem': platform.python_implementation() + ' ' + platform.python_version(),
        'sistema_operacional': platform.platform(),
        'faixas': len(faixas),
        'consultas': len(consultas),
        'consultas_presentes': encontrados,
        'consultas_ausentes': len(consultas) - encontrados,
        'erros_de_correspondencia': erros,
        'semente_aleatoria': SEMENTE,
        'repeticoes': REPETICOES,
        'tempos_segundos': [round(t, 6) for t in tempos],
        'mediana_segundos': round(statistics.median(tempos), 6),
        'media_segundos': round(statistics.mean(tempos), 6),
        'escopo_temporizacao': 'apenas as consultas de busca binaria',
        'nota': 'resultado apenas deste computador; nao representa os resultados do grupo',
    }
    saida = Path(__file__).with_name('resultado_topico5_ipv4_local.json')
    saida.write_text(json.dumps(resultado, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'Encontrados: {encontrados}; nao encontrados: {len(consultas) - encontrados}; erros: {erros}')
    print(f'Mediana: {resultado["mediana_segundos"]} s')
    print(f'Resultado salvo em {saida.name}')


if __name__ == '__main__':
    executar()

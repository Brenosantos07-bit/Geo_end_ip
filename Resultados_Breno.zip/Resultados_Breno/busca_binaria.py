import csv
from ipaddress import IPv4Address

ARQUIVO = "base_ip2location_10000_faixas_ipv4.csv"


def carregar_faixas(caminho):
    faixas = []
    with open(caminho, encoding="utf-8-sig", newline="") as arquivo:
        leitor = csv.DictReader(arquivo)
        for linha in leitor:
            inicio = int(linha["IP inicial (inteiro)"])
            fim = int(linha["IP final (inteiro)"])
            pais = linha["País"]
            faixas.append((inicio, fim, pais))

    faixas.sort(key=lambda faixa: faixa[0])
    for i in range(1, len(faixas)):
        if faixas[i-1][1] >= faixas[i][0]:
            raise ValueError("Existem faixas IPv4 sobrepostas.")
    return faixas


def buscar_pais(faixas, endereco_ip):
    alvo = int(IPv4Address(endereco_ip))
    minimo = 0
    maximo = len(faixas) - 1

    while minimo <= maximo:
        meio = (minimo + maximo) // 2
        inicio, fim, pais = faixas[meio]
        if alvo < inicio:
            maximo = meio - 1
        elif alvo > fim:
            minimo = meio + 1
        else:
            return pais
    return None


faixas = carregar_faixas(ARQUIVO)
print(f"Faixas carregadas: {len(faixas)}")
for ip in ["1.0.16.3", "1.0.0.1"]:
    resultado = buscar_pais(faixas, ip)
    print(f"{ip} -> {resultado if resultado is not None else 'Não encontrado'}")
